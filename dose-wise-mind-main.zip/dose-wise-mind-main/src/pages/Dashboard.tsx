import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Plus, Pill, Settings, Video, Hospital, Calendar } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import AddMedicineModal from "@/components/AddMedicineModal";
import MedicineCard from "@/components/MedicineCard";
import ScheduleItem from "@/components/ScheduleItem";

interface Medicine {
  id: string;
  name: string;
  dosage: string;
  frequency: string;
  times: string[];
  next_dose_time: string | null;
}

const Dashboard = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();
  const [showAddModal, setShowAddModal] = useState(false);
  const [medicines, setMedicines] = useState<Medicine[]>([]);
  const [loading, setLoading] = useState(true);
  const [userName, setUserName] = useState("User");

  useEffect(() => {
    if (!user) {
      navigate("/auth");
      return;
    }
    
    fetchUserProfile();
    fetchMedicines();
  }, [user, navigate]);

  const fetchUserProfile = async () => {
    if (!user) return;
    
    const { data, error } = await supabase
      .from("profiles")
      .select("full_name")
      .eq("id", user.id)
      .single();
    
    if (data && data.full_name) {
      setUserName(data.full_name.split(" ")[0]);
    }
  };

  const fetchMedicines = async () => {
    if (!user) return;
    
    setLoading(true);
    const { data, error } = await supabase
      .from("medicines")
      .select("*")
      .eq("user_id", user.id)
      .eq("active", true)
      .order("created_at", { ascending: false });
    
    if (error) {
      console.error("Error fetching medicines:", error);
      toast({
        title: "Error",
        description: "Failed to load medicines",
        variant: "destructive",
      });
    } else {
      setMedicines(data || []);
    }
    setLoading(false);
  };

  const addMedicine = async (medicine: Omit<Medicine, "id">) => {
    if (!user) return;
    
    const { data, error } = await supabase
      .from("medicines")
      .insert([{
        user_id: user.id,
        name: medicine.name,
        dosage: medicine.dosage,
        frequency: medicine.frequency,
        times: medicine.times,
        next_dose_time: medicine.next_dose_time,
      }])
      .select()
      .single();
    
    if (error) {
      console.error("Error adding medicine:", error);
      toast({
        title: "Error",
        description: "Failed to add medicine",
        variant: "destructive",
      });
    } else {
      setMedicines([...medicines, data]);
      setShowAddModal(false);
      toast({
        title: "Success!",
        description: "Medicine added successfully",
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-soft pb-20">
      {/* Header */}
      <header className="bg-gradient-primary text-white p-6 shadow-medium">
        <div className="container mx-auto max-w-4xl">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-2xl font-bold">Hello, {userName}!</h1>
              <p className="text-white/80">Here's your health overview</p>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="text-white hover:bg-white/20"
              onClick={() => navigate("/settings")}
            >
              <Settings className="h-6 w-6" />
            </Button>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-2 gap-4 mt-6">
            <Card className="bg-white/10 backdrop-blur border-white/20 p-4">
              <div className="text-white/80 text-sm mb-1">Active Meds</div>
              <div className="text-2xl font-bold">{medicines.length}</div>
            </Card>
            <Card className="bg-white/10 backdrop-blur border-white/20 p-4">
              <div className="text-white/80 text-sm mb-1">Next Dose</div>
              <div className="text-2xl font-bold">
                {medicines[0]?.times[0] || "--:--"}
              </div>
            </Card>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto max-w-4xl p-4">
        {/* Emergency Actions */}
        <div className="grid grid-cols-2 gap-3 mb-6">
          <Button
            variant="outline"
            className="h-20 border-2 hover:border-destructive hover:bg-destructive/5"
          >
            <Hospital className="h-6 w-6 mr-2 text-destructive" />
            <div className="text-left">
              <div className="font-semibold">Emergency</div>
              <div className="text-xs text-muted-foreground">Find Hospitals</div>
            </div>
          </Button>
          <Button
            variant="outline"
            className="h-20 border-2 hover:border-primary hover:bg-primary-light"
          >
            <Video className="h-6 w-6 mr-2 text-primary" />
            <div className="text-left">
              <div className="font-semibold">Doctor Call</div>
              <div className="text-xs text-muted-foreground">Connect Now</div>
            </div>
          </Button>
        </div>

        {/* Medicines Section */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold">My Medicines</h2>
            <Button
              className="bg-gradient-primary text-white hover:opacity-90 shadow-medium"
              onClick={() => setShowAddModal(true)}
            >
              <Plus className="h-5 w-5 mr-2" />
              Add Medicine
            </Button>
          </div>

          <div className="space-y-3">
            {loading ? (
              <Card className="p-8 text-center">
                <p className="text-muted-foreground">Loading medicines...</p>
              </Card>
            ) : medicines.length === 0 ? (
              <Card className="p-8 text-center">
                <Pill className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <p className="text-muted-foreground mb-4">No medicines added yet</p>
                <Button
                  variant="outline"
                  onClick={() => setShowAddModal(true)}
                >
                  Add Your First Medicine
                </Button>
              </Card>
            ) : (
              medicines.map((medicine) => (
                <MedicineCard key={medicine.id} medicine={medicine} onUpdate={fetchMedicines} />
              ))
            )}
          </div>
        </div>

        {/* Today's Schedule */}
        <Card className="p-6 bg-gradient-card">
          <div className="flex items-center gap-3 mb-4">
            <Calendar className="h-6 w-6 text-primary" />
            <h2 className="text-xl font-bold">Today's Schedule</h2>
          </div>
          <div className="space-y-3">
            {medicines.length === 0 ? (
              <p className="text-muted-foreground text-center py-4">No scheduled doses</p>
            ) : (
              medicines.flatMap(med => 
                med.times.map((time, idx) => (
                  <ScheduleItem 
                    key={`${med.id}-${idx}`}
                    time={time}
                    medicine={`${med.name} ${med.dosage}`}
                    status="upcoming"
                  />
                ))
              )
            )}
          </div>
        </Card>
      </main>

      <AddMedicineModal
        open={showAddModal}
        onClose={() => setShowAddModal(false)}
        onAdd={addMedicine}
      />
    </div>
  );
};

export default Dashboard;
