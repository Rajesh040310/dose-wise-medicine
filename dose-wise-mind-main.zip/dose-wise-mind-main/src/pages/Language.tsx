import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useNavigate } from "react-router-dom";
import { Languages } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

const Language = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    if (!user) {
      navigate("/auth");
    }
  }, [user, navigate]);

  const selectLanguage = async (lang: string) => {
    localStorage.setItem("language", lang);
    
    // Update user profile with language preference
    if (user) {
      const { error } = await supabase
        .from("profiles")
        .update({ preferred_language: lang })
        .eq("id", user.id);
      
      if (error) {
        console.error("Error updating language:", error);
        toast({
          title: "Warning",
          description: "Language saved locally but not synced to profile",
          variant: "destructive",
        });
      }
    }
    
    navigate("/dashboard");
  };

  return (
    <div className="min-h-screen bg-gradient-soft flex items-center justify-center p-4">
      <Card className="w-full max-w-md p-8 shadow-strong">
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="bg-gradient-primary rounded-full p-4">
              <Languages className="h-10 w-10 text-white" />
            </div>
          </div>
          <h1 className="text-3xl font-bold mb-2 text-gradient">Choose Your Language</h1>
          <p className="text-muted-foreground">Select your preferred language to continue</p>
        </div>

        <div className="space-y-4">
          <LanguageButton
            language="English"
            nativeText="English"
            onClick={() => selectLanguage("en")}
          />
          <LanguageButton
            language="Hindi"
            nativeText="हिन्दी"
            onClick={() => selectLanguage("hi")}
          />
          <LanguageButton
            language="Telugu"
            nativeText="తెలుగు"
            onClick={() => selectLanguage("te")}
          />
        </div>
      </Card>
    </div>
  );
};

const LanguageButton = ({ language, nativeText, onClick }: { language: string; nativeText: string; onClick: () => void }) => {
  return (
    <Button
      variant="outline"
      className="w-full h-16 text-lg border-2 hover:border-primary hover:bg-primary-light transition-smooth"
      onClick={onClick}
    >
      <span className="font-semibold">{language}</span>
      <span className="ml-2 text-muted-foreground">({nativeText})</span>
    </Button>
  );
};

export default Language;
