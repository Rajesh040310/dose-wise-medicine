import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { Pill, Bell, Heart, Shield, Scan, Video } from "lucide-react";

const Landing = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-soft">
      {/* Hero Section */}
      <section className="relative overflow-hidden px-4 py-16 md:py-24">
        <div className="container mx-auto max-w-6xl text-center">
          <div className="mb-6 flex justify-center">
            <div className="bg-gradient-primary rounded-full p-6 shadow-strong">
              <Pill className="h-12 w-12 text-white" />
            </div>
          </div>
          
          <h1 className="mb-6 text-4xl md:text-6xl font-bold text-gradient">
            MediCare Plus
          </h1>
          
          <p className="mb-8 text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
            Your intelligent medicine companion. Never miss a dose, track your health, and connect with doctors instantly.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              className="bg-gradient-primary text-white hover:opacity-90 transition-smooth shadow-medium text-lg px-8 py-6"
              onClick={() => navigate("/auth")}
            >
              Get Started Free
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="border-2 border-primary text-primary hover:bg-primary-light text-lg px-8 py-6"
              onClick={() => navigate("/auth")}
            >
              Learn More
            </Button>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="px-4 py-16 bg-white">
        <div className="container mx-auto max-w-6xl">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-gradient">
            Everything You Need
          </h2>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <FeatureCard
              icon={<Scan className="h-8 w-8" />}
              title="Smart Scanner"
              description="Scan medicine labels and barcodes for instant dosage tracking"
            />
            <FeatureCard
              icon={<Bell className="h-8 w-8" />}
              title="AI Reminders"
              description="Intelligent notifications that learn your habits"
            />
            <FeatureCard
              icon={<Heart className="h-8 w-8" />}
              title="Health Insights"
              description="Track how you feel and get personalized recommendations"
            />
            <FeatureCard
              icon={<Shield className="h-8 w-8" />}
              title="Secure & Private"
              description="Your health data is encrypted and protected"
            />
            <FeatureCard
              icon={<Video className="h-8 w-8" />}
              title="Doctor Connect"
              description="Video calls and chat with healthcare professionals"
            />
            <FeatureCard
              icon={<Pill className="h-8 w-8" />}
              title="Dose Tracking"
              description="Never double-dose or miss medications again"
            />
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="px-4 py-16 bg-gradient-card">
        <div className="container mx-auto max-w-4xl text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to take control of your health?
          </h2>
          <p className="text-lg text-muted-foreground mb-8">
            Join thousands of users managing their medications with confidence
          </p>
          <Button 
            size="lg" 
            className="bg-gradient-primary text-white hover:opacity-90 transition-smooth shadow-medium text-lg px-8 py-6"
            onClick={() => navigate("/auth")}
          >
            Start Your Journey
          </Button>
        </div>
      </section>
    </div>
  );
};

const FeatureCard = ({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) => {
  return (
    <div className="bg-gradient-card rounded-2xl p-6 shadow-soft hover:shadow-medium transition-smooth border border-border">
      <div className="bg-gradient-primary rounded-xl p-3 w-fit mb-4 text-white">
        {icon}
      </div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-muted-foreground">{description}</p>
    </div>
  );
};

export default Landing;
