import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Scan } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface AddMedicineModalProps {
  open: boolean;
  onClose: () => void;
  onAdd: (medicine: {
    name: string;
    dosage: string;
    frequency: string;
    times: string[];
    next_dose_time: string | null;
  }) => void;
}

const AddMedicineModal = ({ open, onClose, onAdd }: AddMedicineModalProps) => {
  const { toast } = useToast();
  const [name, setName] = useState("");
  const [dosage, setDosage] = useState("");
  const [frequency, setFrequency] = useState("");
  const [time1, setTime1] = useState("");
  const [time2, setTime2] = useState("");

  const handleSubmit = () => {
    if (!name || !dosage || !frequency || !time1) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    const times = time2 ? [time1, time2] : [time1];
    onAdd({
      name,
      dosage,
      frequency,
      times,
      next_dose_time: times[0],
    });

    // Reset form
    setName("");
    setDosage("");
    setFrequency("");
    setTime1("");
    setTime2("");
  };

  const handleScan = () => {
    toast({
      title: "Scanner Coming Soon",
      description: "Medicine scanning feature will be available soon",
    });
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="text-2xl">Add New Medicine</DialogTitle>
          <DialogDescription>
            Enter medicine details or scan the label
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <Button
            variant="outline"
            className="w-full h-16 border-2 border-dashed border-primary hover:bg-primary-light"
            onClick={handleScan}
          >
            <Scan className="h-6 w-6 mr-2 text-primary" />
            <div className="text-left">
              <div className="font-semibold">Scan Medicine Label</div>
              <div className="text-xs text-muted-foreground">Quick add via camera</div>
            </div>
          </Button>

          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-background px-2 text-muted-foreground">Or enter manually</span>
            </div>
          </div>

          <div>
            <Label htmlFor="name">Medicine Name *</Label>
            <Input
              id="name"
              placeholder="e.g., Aspirin"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="mt-1"
            />
          </div>

          <div>
            <Label htmlFor="dosage">Dosage *</Label>
            <Input
              id="dosage"
              placeholder="e.g., 100mg"
              value={dosage}
              onChange={(e) => setDosage(e.target.value)}
              className="mt-1"
            />
          </div>

          <div>
            <Label htmlFor="frequency">Frequency *</Label>
            <Input
              id="frequency"
              placeholder="e.g., 2x daily"
              value={frequency}
              onChange={(e) => setFrequency(e.target.value)}
              className="mt-1"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="time1">Time 1 *</Label>
              <Input
                id="time1"
                type="time"
                value={time1}
                onChange={(e) => setTime1(e.target.value)}
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="time2">Time 2</Label>
              <Input
                id="time2"
                type="time"
                value={time2}
                onChange={(e) => setTime2(e.target.value)}
                className="mt-1"
              />
            </div>
          </div>
        </div>

        <div className="flex gap-3">
          <Button variant="outline" onClick={onClose} className="flex-1">
            Cancel
          </Button>
          <Button
            onClick={handleSubmit}
            className="flex-1 bg-gradient-primary text-white hover:opacity-90"
          >
            Add Medicine
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default AddMedicineModal;
