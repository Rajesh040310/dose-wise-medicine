import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Pill, Clock, AlertCircle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";

interface MedicineCardProps {
  medicine: {
    id: string;
    name: string;
    dosage: string;
    frequency: string;
    times: string[];
    next_dose_time: string | null;
  };
  onUpdate: () => void;
}

const MedicineCard = ({ medicine, onUpdate }: MedicineCardProps) => {
  const { toast } = useToast();
  const { user } = useAuth();

  const markAsTaken = async () => {
    if (!user) return;
    
    const now = new Date();
    const { error } = await supabase
      .from("dose_tracking")
      .insert([{
        medicine_id: medicine.id,
        user_id: user.id,
        scheduled_time: now.toISOString(),
        taken_at: now.toISOString(),
        status: "taken",
      }]);
    
    if (error) {
      console.error("Error marking dose:", error);
      toast({
        title: "Error",
        description: "Failed to mark dose as taken",
        variant: "destructive",
      });
    } else {
      toast({
        title: "Dose Recorded!",
        description: "How are you feeling after taking your medicine?",
      });
      onUpdate();
    }
  };

  const skipDose = async () => {
    if (!user) return;
    
    const now = new Date();
    const { error } = await supabase
      .from("dose_tracking")
      .insert([{
        medicine_id: medicine.id,
        user_id: user.id,
        scheduled_time: now.toISOString(),
        status: "skipped",
      }]);
    
    if (error) {
      console.error("Error skipping dose:", error);
      toast({
        title: "Error",
        description: "Failed to record skipped dose",
        variant: "destructive",
      });
    } else {
      toast({
        title: "Dose Skipped",
        description: "Don't forget to take it later if needed!",
      });
      onUpdate();
    }
  };

  return (
    <Card className="p-5 bg-gradient-card border-2 hover:shadow-medium transition-smooth">
      <div className="flex items-start gap-4">
        <div className="bg-gradient-primary rounded-xl p-3 text-white">
          <Pill className="h-6 w-6" />
        </div>
        
        <div className="flex-1">
          <h3 className="text-lg font-semibold mb-1">{medicine.name}</h3>
          <p className="text-sm text-muted-foreground mb-3">
            {medicine.dosage} • {medicine.frequency}
          </p>
          
          <div className="flex items-center gap-2 text-sm mb-3">
            <Clock className="h-4 w-4 text-primary" />
            <span className="text-muted-foreground">Times:</span>
            <span className="font-medium">{medicine.times.join(", ")}</span>
          </div>

          <div className="flex items-center gap-2 p-2 bg-primary-light rounded-lg">
            <AlertCircle className="h-4 w-4 text-primary" />
            <span className="text-sm font-medium">
              Next dose at {medicine.next_dose_time || medicine.times[0]}
            </span>
          </div>
        </div>
      </div>

      <div className="flex gap-2 mt-4">
        <Button variant="outline" size="sm" className="flex-1" onClick={markAsTaken}>
          Mark Taken
        </Button>
        <Button variant="outline" size="sm" className="flex-1" onClick={skipDose}>
          Skip
        </Button>
        <Button variant="outline" size="sm" className="flex-1">
          Details
        </Button>
      </div>
    </Card>
  );
};

export default MedicineCard;
