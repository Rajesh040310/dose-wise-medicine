import { Bell } from "lucide-react";

interface ScheduleItemProps {
  time: string;
  medicine: string;
  status: "taken" | "upcoming";
}

const ScheduleItem = ({ time, medicine, status }: ScheduleItemProps) => {
  return (
    <div className="flex items-center gap-4 p-3 bg-white rounded-lg border">
      <div className={`h-12 w-12 rounded-full flex items-center justify-center ${status === "taken" ? "bg-success/10" : "bg-primary-light"}`}>
        <Bell className={`h-6 w-6 ${status === "taken" ? "text-success" : "text-primary"}`} />
      </div>
      <div className="flex-1">
        <div className="font-semibold">{medicine}</div>
        <div className="text-sm text-muted-foreground">{time}</div>
      </div>
      {status === "taken" && (
        <div className="text-success text-sm font-medium">✓ Taken</div>
      )}
    </div>
  );
};

export default ScheduleItem;
